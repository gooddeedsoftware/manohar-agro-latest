<?php

return [
    'previous' => '&laquo; Trước',
    'next' => 'Sau &raquo;',
];
